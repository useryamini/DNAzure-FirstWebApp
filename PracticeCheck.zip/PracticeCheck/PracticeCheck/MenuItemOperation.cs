﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;
using PracticeCheck.Models;


namespace PracticeCheck
{
    public class MenuItemOperation
    {
        public static string sqlDataSource = "Server=.;Database=Hotel;Trusted_Connection=True;MultipleActiveResultSets=true;";

        public static IEnumerable<MenuItem> GetConnection()
        {
            List<MenuItem> Items = new List<MenuItem>();
            //var list = new List<string> { "Starter", "Main Course", "Drinks", "Dessert" };

            using (SqlConnection con = new SqlConnection(sqlDataSource))
            {
                con.Open();
                using (SqlCommand cmd = new SqlCommand("select * from Items", con))
                {

                    SqlDataReader rd = cmd.ExecuteReader();

                    while (rd.Read())
                    {
                        Items.Add(new MenuItem
                        {
                            ItemId = Convert.ToInt32(rd["ItemId"]),
                            ItemName = rd["ItemName"].ToString(),
                            ItemType = rd["ItemType"].ToString(),
                            ItemPrice = Convert.ToInt32(rd["ItemPrice"]),
                        }); 
                    }
                    con.Close();
                }


                return Items;
            }
        }
        public static void AddItem(MenuItem mItem)
        {
            using (SqlConnection con = new SqlConnection(sqlDataSource))
            {
                SqlCommand cmd = new SqlCommand("Insert into Items(ItemId,ItemName,ItemType,ItemPrice) values (@Id,@Name,@Type,@Price)",con);
                cmd.Parameters.AddWithValue("@Id", mItem.ItemId);
                cmd.Parameters.AddWithValue("@Name", mItem.ItemName);
                cmd.Parameters.AddWithValue("@Type", mItem.ItemType);
                cmd.Parameters.AddWithValue("@Price", mItem.ItemPrice);
                con.Open();
                cmd.ExecuteNonQuery();
                con.Close();
            }
        }
        public static void Update(int id, MenuItem menuitem)
        {
        //    var list = new List<string> { "Starter", "Main Course", "Drinks", "Dessert" };
            using (SqlConnection con = new SqlConnection(sqlDataSource))
            {
                SqlCommand cmd = new SqlCommand("update Items set ItemId = @Id , ItemName = @ItemName ,ItemType = @ItemType,ItemPrice = @ItemPrice where ItemId=@ItemId", con);
                

                cmd.Parameters.AddWithValue("@ItemId", id);
                cmd.Parameters.AddWithValue("@Id", menuitem.ItemId);
                cmd.Parameters.AddWithValue("@ItemName", menuitem.ItemName);
                cmd.Parameters.AddWithValue("@ItemType", menuitem.ItemType);
                cmd.Parameters.AddWithValue("@ItemPrice", menuitem.ItemPrice);
             
                con.Open();
                cmd.ExecuteNonQuery();
                con.Close();

            }
        }
        public static void InsertIntoCart(List<Cart> cart)
        {
            using (SqlConnection con = new SqlConnection(sqlDataSource))
            {
                con.Open();

                foreach (var i in cart)
                {
                    SqlCommand cmd = new SqlCommand("Insert into cart(ItemId,UserId) values(@id,@uid)", con);

                    cmd.Parameters.AddWithValue("@id", i.ItemId);
                    cmd.Parameters.AddWithValue("@uid", i.UserId);

                    cmd.ExecuteNonQuery();
                }
            }
        }
         public static List<MenuItem> CartList(int userid,ref int totalprice)
        {

            List<MenuItem> Items = new List<MenuItem>();
            List<int> list = new List<int>();
                
            //var l = new List<string> { "Starter", "Main Course", "Drinks", "Dessert" };


            using (SqlConnection con = new SqlConnection(sqlDataSource))
            {
                con.Open();
                using (SqlCommand cmd = new SqlCommand("select ItemId from Cart where Userid = @userid", con))
                {
                   // cmd.Connection = con;
                   // cmd.CommandText = "select MenuItemId from Cart where Userid = @userid";
                    cmd.Parameters.AddWithValue("@userid",userid);
                    SqlDataReader rd = cmd.ExecuteReader();
                     while (rd.Read())
                     {
                         list.Add(Convert.ToInt32(rd["ItemId"]));
                     }
                    rd.Close();
                      foreach (var i in list)
                      {
                        
                       cmd.CommandText = "select * from Items where ItemId = @i";
                       cmd.Parameters.AddWithValue("@i", i);
                       SqlDataReader rd1 = cmd.ExecuteReader();
                        while (rd1.Read())
                         {
                             Items.Add(new MenuItem
                             {
                                 ItemId = Convert.ToInt32(rd1["ItemId"]),
                                 ItemName = rd1["ItemName"].ToString(),
                                 ItemType = rd1["ItemType"].ToString(),
                                 ItemPrice = Convert.ToInt32(rd1["ItemPrice"]),
                                
                         });
                           totalprice += Convert.ToInt32(rd1["ItemPrice"]);

                         }
                        cmd.Parameters.Clear();
                        rd1.Close();
                    }
                    con.Close();

                 }

             }
            return Items;
           
        }
        public static string Delete(int cartid)
        {
            SqlConnection con = new SqlConnection(sqlDataSource);
            SqlCommand sqlCmd = new SqlCommand("delete from Cart where UserId = @cartid",con);
            sqlCmd.CommandType = CommandType.Text;
         //   sqlCmd.CommandText = "delete from Cart where Id =@cartid";
         //   sqlCmd.Connection = con;
            con.Open();
            sqlCmd.Parameters.AddWithValue("@cartid", cartid);
            int i = sqlCmd.ExecuteNonQuery();
            if (i >= 1)
                return "record deleted";
            else
                return "no record";

        }

        public static void Insert(User user)
        {
            SqlConnection con = new SqlConnection(sqlDataSource);
            SqlCommand sqlCmd = new SqlCommand("Insert into Users(Id,UserName,Password) values (@Id,@UserName,@Password)",con);
           // sqlCmd.CommandType = CommandType.Text;

            sqlCmd.Parameters.AddWithValue("@Id", user.Id);
            sqlCmd.Parameters.AddWithValue("@UserName", user.UserName);
            sqlCmd.Parameters.AddWithValue("@Password", user.Password);

            con.Open();
            sqlCmd.ExecuteNonQuery();
            con.Close();

        }
        public static List<User> UserList()
        {
            List<User> users = new List<User>();

            using (SqlConnection con = new SqlConnection(sqlDataSource))
            {
                con.Open();
                using (SqlCommand cmd = new SqlCommand("select * from Users",con))
                {
                    SqlDataReader rd = cmd.ExecuteReader();
                    while (rd.Read())
                    {
                        users.Add(new User
                        {
                            Id = Convert.ToInt32(rd["Id"]),
                            UserName = rd["UserName"].ToString(),
                            Password = rd["Password"].ToString(),

                        });
                    }
                    con.Close();
                }

            }
            return users;
        }
        }
    }
