﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using PracticeCheck.Models;


namespace PracticeCheck.Controllers
{
    [Route("api/[controller]")]
    [AllowAnonymous]

    public class AnonymousUserController : Controller
    {
        [HttpGet]
        public IEnumerable<MenuItem> Get()
        {
            return MenuItemOperation.GetConnection();
        }
    }
}
