﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using PracticeCheck.Models;
using Microsoft.AspNetCore.Authorization;

namespace PracticeCheck.Controllers
{
    [Route("api/[controller]")]
    [Authorize(Roles = "Customer")]

    public class CustomerController : Controller
    {
        [HttpGet]
        public IEnumerable<MenuItem> Get()
        {
            return MenuItemOperation.GetConnection();

        }
    
        [HttpPost]
        public IActionResult Post([FromBody] List<Cart> cart)
        {
            MenuItemOperation.InsertIntoCart(cart);
            return Ok(cart);
        }

        [HttpGet("{userid}", Name = "Get Customer")]
        public object Get(int userid)
        {
            int totalprice = 0;
            List<MenuItem> list = new List<MenuItem>(MenuItemOperation.CartList(userid, ref totalprice));

            return new { list, totalprice };
        }
      //  DELETE: api/ApiWithActions/5
        [HttpDelete("{cartid}")]
        public string Delete(int cartid)
        {
            return MenuItemOperation.Delete(cartid);
        }
    }
}
