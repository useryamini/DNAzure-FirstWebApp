﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using PracticeCheck.Models;
using Microsoft.AspNetCore.Authorization;

namespace PracticeCheck.Controllers
{
    [Route("api/[controller]")]
    [Authorize(Roles = "Admin")]

    public class AdminController : Controller
    {
        [HttpGet]
        public IEnumerable<MenuItem> Get()
        {
            return MenuItemOperation.GetConnection();
        }

        [HttpPost]
        public IActionResult Post([FromBody] MenuItem mItem)
        {
            MenuItemOperation.AddItem(mItem);
            return Ok(mItem);
        }

        [HttpPut("{id}")]
        public IActionResult Put(int id, [FromBody] MenuItem menuitem)
        {
            MenuItemOperation.Update(id, menuitem);
            return Ok(menuitem);
        }


    }
}
