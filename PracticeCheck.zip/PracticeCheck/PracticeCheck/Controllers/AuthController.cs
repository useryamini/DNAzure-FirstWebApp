﻿using System;
using System.Collections.Generic;
using Microsoft.AspNetCore.Mvc;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Text;
using Microsoft.IdentityModel.Tokens;

namespace PracticeCheck.Controllers
{
    public class AuthController : Controller
    {
        private const string SECRET_KEY = "abcdefghijklnnaopapalajd";
        public static readonly SymmetricSecurityKey SIGNING_KEY = new
                      SymmetricSecurityKey(Encoding.UTF8.GetBytes(SECRET_KEY));
        [HttpGet]
        [Route("api/Auth/{userId}")]
        public IActionResult Get(int userId)
        {
            string userRole;
            List<String> claims = new List<string> { "Admin", "Customer" };
            if (userId == -1)
            {
                //userRole = claims[2];
                return BadRequest();
            }
            else if (userId == 1)
            {
                userRole = claims[0];
                return new ObjectResult(GenerateToken(userRole));
            }
            else
            {
                userRole = claims[1];
                return new ObjectResult(GenerateToken(userRole));
            }
        }
        //[HttpGet]
        //[Route("api/Auth/{username}/{password}")]
        //public IActionResult Get(string username, string password)
        //{
        //    if (username == password)
        //        return new ObjectResult(GenerateToken(username));
        //    else
        //        return BadRequest();
        //}


        public string GenerateToken(string userRole)
        {
            var token = new JwtSecurityToken(
               claims: new Claim[] { new Claim(ClaimTypes.Role, userRole) },
               notBefore: new DateTimeOffset(DateTime.Now).DateTime,
               expires: new DateTimeOffset(DateTime.Now.AddMinutes(60)).DateTime,
               signingCredentials: new SigningCredentials(SIGNING_KEY, SecurityAlgorithms.HmacSha256)
               );
            return new JwtSecurityTokenHandler().WriteToken(token);
        }

    }
}
