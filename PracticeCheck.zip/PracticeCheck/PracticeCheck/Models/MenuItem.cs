﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations.Schema;


namespace PracticeCheck.Models
{
    public class MenuItem
    {
        public int ItemId { get; set; }

        public string ItemName { get; set; }
        public string ItemType { get; set; }
        public int ItemPrice { get; set; }
    }
}
